import React from 'react';

function InfoGroup (props) {
	
	return (<>
		<div>InfoGroup</div>
	</>);
}

export default InfoGroup;