import React from 'react';

function InfoPerson (props) {
	
	return (<>
		<div>InfoPerson</div>
	</>);
}

export default InfoPerson;