import React from 'react';

function List (props) {
	
	return (<>
		<div>List</div>
	</>);
}

export default List;